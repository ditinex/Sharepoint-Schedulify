# Sharepoint-Schedulify

Nd+%8h5rf:J"jKWN

about:debugging

https://jqueryui.com/dialog/

http://zerobug.in/


To install with zip file:

zip -r blitzkreig.zip ./*

about:addons -> Settings -> Install

about:config -> xpinstall.signatures.required;false
